namespace OnlineCMS.DTOs
{
    public class AuthResponse
    {
        public bool Success { get; set; } = false;
        public string Token { get; set; } = string.Empty;
        public List<string> Errors { get; set; } = new();
    }
}
