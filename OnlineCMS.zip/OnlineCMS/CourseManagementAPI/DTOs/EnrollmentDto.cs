namespace OnlineCMS.DTOs
{
    public class EnrollmentDto
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; } = string.Empty;
        public int CourseId { get; set; }
        public string CourseTitle { get; set; } = string.Empty;
        public DateOnly EnrollmentDate { get; set; }
    }
}
