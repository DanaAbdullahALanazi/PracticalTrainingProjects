using System.ComponentModel.DataAnnotations;
namespace OnlineCMS.Models
{
    public class Instructor
    {
        public int Id { get; set; }
        [Required]
        public string Name { get; set; } = string.Empty;
        [Required]
        public string Email { get; set; } = string.Empty;
        [Required]
        public string Bio { get; set; } = string.Empty;
        public ICollection<Course> Courses { get; set; } = [];  // ✅

    }//end class
}//end namespace
