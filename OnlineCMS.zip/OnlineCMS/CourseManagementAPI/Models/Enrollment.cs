using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace OnlineCMS.Models
{
    public class Enrollment
    {
        [ForeignKey("StudentId")]
        public required Student Student { get; set; }
        public int StudentId { get; set; }
        [ForeignKey("CourseId")]
        public required Course Course { get; set; }
        public int CourseId { get; set; }
        [Required]
        public DateOnly EnrollmentDate { get; set; }
    }//end class
}//end namespace
