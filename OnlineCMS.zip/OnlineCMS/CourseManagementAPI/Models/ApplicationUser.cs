using Microsoft.AspNetCore.Identity;

namespace OnlineCMS.Models
{
    public class ApplicationUser : IdentityUser
    {
        // Used for display name (optional but helpful for UI or audit logs)
        public string FullName { get; set; } = string.Empty;

        // Link to Student profile (nullable — only applies to student users)
        public int? StudentId { get; set; }
        public Student? Student { get; set; }

    }
}
