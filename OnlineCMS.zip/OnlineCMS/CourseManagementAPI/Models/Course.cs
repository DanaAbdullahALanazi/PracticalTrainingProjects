using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace OnlineCMS.Models
{
    public enum Category
    {
        Programming,
        DataScience,
        Design,
        Business,
        Marketing,
        PersonalDevelopment,
        Language,
        HealthAndFitness,
        Finance,
        Education
    }

    public class Course
    {
        public int Id { get; set; }
        [ForeignKey("InstructorId")]
        public int InstructorId { get; set; }
        public Instructor? Instructor { get; set; }
        [Required]
        public string Title { get; set; } = string.Empty;
        [Required]
        public string Description { get; set; } = string.Empty;
        [Required]
        public Category Category { get; set; }
        [Required]
        public ICollection<Enrollment> Enrollments { get; set; } = new List<Enrollment>();
    }//end class
}//end namespace
