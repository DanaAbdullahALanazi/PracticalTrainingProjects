using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using OnlineCMS.Models;
using OnlineCMS.Data;

namespace OnlineCMS.Data
{
    public static class SeedData
    {
        public static async Task InitializeAsync(IServiceProvider serviceProvider)
        {
            using var scope = serviceProvider.CreateScope();

            var context = scope.ServiceProvider.GetRequiredService<AppDBContext>();
            var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();
            var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();

            context.Database.Migrate();

            // 1️⃣ Seed Roles
            string[] roles = { "Admin", "Student" };
            foreach (var role in roles)
            {
                if (!await roleManager.RoleExistsAsync(role))
                {
                    await roleManager.CreateAsync(new IdentityRole(role));
                }
            }

            // 2️⃣ Seed Admin User
            var adminEmail = "admin@onlinecms.local";
            if (await userManager.FindByEmailAsync(adminEmail) == null)
            {
                var adminUser = new ApplicationUser
                {
                    UserName = "admin",
                    Email = adminEmail,
                    FullName = "System Administrator",
                    EmailConfirmed = true
                };

                var result = await userManager.CreateAsync(adminUser, "Admin123!");
                if (result.Succeeded)
                {
                    await userManager.AddToRoleAsync(adminUser, "Admin");
                }
            }

            // 3️⃣ Seed Instructor
            if (!context.Instructors.Any())
            {
                var instructor = new Instructor
                {
                    Name = "John Smith",
                    Email = "john.smith@cms.edu",
                    Bio = "Expert in backend development"
                };
                context.Instructors.Add(instructor);
                await context.SaveChangesAsync();

                // 4️⃣ Seed Course
                var course = new Course
                {
                    Title = "ASP.NET Core Fundamentals",
                    Description = "Intro to Web API development with Entity Framework and JWT",
                    Category = Category.Programming,
                    InstructorId = instructor.Id
                };
                context.Courses.Add(course);
                await context.SaveChangesAsync();

                // 5️⃣ Seed Student + Identity Account
                var studentEntity = new Student
                {
                    Name = "Alice Johnson",
                    Email = "alice@student.edu",
                    PasswordHash = string.Empty // will be linked to identity user
                };
                context.Students.Add(studentEntity);
                await context.SaveChangesAsync();

                var studentUser = new ApplicationUser
                {
                    UserName = "alice.student",
                    Email = studentEntity.Email,
                    FullName = studentEntity.Name,
                    StudentId = studentEntity.Id,
                    EmailConfirmed = true
                };
                var studentCreate = await userManager.CreateAsync(studentUser, "Student123!");
                if (studentCreate.Succeeded)
                {
                    await userManager.AddToRoleAsync(studentUser, "Student");
                }

                // 6️⃣ Seed Enrollment
                // ...existing code...
                var enrollment = new Enrollment
                {
                    StudentId = studentEntity.Id,
                    Student = studentEntity, // Set required navigation property
                    CourseId = course.Id,
                    Course = course,         // Set required navigation property
                    EnrollmentDate = DateOnly.FromDateTime(DateTime.UtcNow)
                };
                context.Enrollments.Add(enrollment);
                await context.SaveChangesAsync();

            }
        }

        public static async Task SeedRolesAsync(IServiceProvider serviceProvider)
        {
            var roleManager = serviceProvider.GetRequiredService<RoleManager<IdentityRole>>();
            string[] roles = { "Admin", "Student" };

            foreach (var role in roles)
            {
                if (!await roleManager.RoleExistsAsync(role))
                    await roleManager.CreateAsync(new IdentityRole(role));
            }
        }

    }
}
