using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using OnlineCMS.Data;
using OnlineCMS.DTOs;
using Microsoft.EntityFrameworkCore;

namespace OnlineCMS.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class InstructorsController : ControllerBase
    {
        private readonly AppDBContext _context;

        public InstructorsController(AppDBContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var instructors = await _context.Instructors
                .Select(i => new InstructorDto
                {
                    Id = i.Id,
                    Name = i.Name,
                    Email = i.Email,
                    Bio = i.Bio
                })
                .ToListAsync();

            return Ok(instructors);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public async Task<IActionResult> Create(InstructorDto dto)
        {
            var instructor = new Models.Instructor
            {
                Name = dto.Name,
                Email = dto.Email,
                Bio = dto.Bio
            };

            _context.Instructors.Add(instructor);
            await _context.SaveChangesAsync();
            return Ok();
        }
    }
}
