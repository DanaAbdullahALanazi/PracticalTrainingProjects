using Microsoft.AspNetCore.Mvc;
using OnlineCMS.DTOs;
using OnlineCMS.Services;

namespace OnlineCMS.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;

        public AuthController(IAuthService authService)
        {
            _authService = authService;
        }

        [HttpPost("register-student")]
        public async Task<IActionResult> RegisterStudent(RegisterStudentDto dto)
        {
            var result = await _authService.RegisterStudentAsync(dto);
            return result.Success ? Ok(result) : BadRequest(result);
        }

        [HttpPost("register-admin")]
        public async Task<IActionResult> RegisterAdmin(RegisterAdminDto dto)
        {
            var result = await _authService.RegisterAdminAsync(dto);
            return result.Success ? Ok(result) : BadRequest(result);
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginDto dto)
        {
            var result = await _authService.LoginAsync(dto);
            return result.Success ? Ok(result) : Unauthorized(result);
        }
    }
}
