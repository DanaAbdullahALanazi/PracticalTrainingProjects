using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using OnlineCMS.Services;
using OnlineCMS.DTOs;

namespace OnlineCMS.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EnrollmentsController : ControllerBase
    {
        private readonly IEnrollmentService _enrollmentService;

        public EnrollmentsController(IEnrollmentService enrollmentService)
        {
            _enrollmentService = enrollmentService;
        }

        [Authorize(Roles = "Student")]
        [HttpPost("enroll")]
        public async Task<IActionResult> Enroll([FromQuery] int studentId, [FromQuery] int courseId)
        {
            var result = await _enrollmentService.EnrollStudentAsync(studentId, courseId);
            return result ? Ok("Enrollment successful.") : BadRequest("Student already enrolled in this course.");
        }

        [Authorize(Roles = "Student")]
        [HttpGet("student/{studentId}")]
        public async Task<IActionResult> GetStudentEnrollments(int studentId)
        {
            var enrollments = await _enrollmentService.GetEnrollmentsByStudentAsync(studentId);
            return Ok(enrollments);
        }

        [Authorize(Roles = "Admin")]
        [HttpGet("all")]
        public async Task<IActionResult> GetAllEnrollments()
        {
            var enrollments = await _enrollmentService.GetAllEnrollmentsAsync();
            return Ok(enrollments);
        }
    }
}
