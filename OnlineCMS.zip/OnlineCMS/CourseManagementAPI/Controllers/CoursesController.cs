using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnlineCMS.Data;
using OnlineCMS.DTOs;

namespace OnlineCMS.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CoursesController : ControllerBase
    {
        private readonly AppDBContext _context;

        public CoursesController(AppDBContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<List<CourseDto>>> GetAll()
        {
            var courses = await _context.Courses
                .Include(c => c.Instructor)
                .Select(c => new CourseDto
                {
                    Id = c.Id,
                    Title = c.Title,
                    Description = c.Description,
                    Category = c.Category.ToString(),
                    InstructorId = c.InstructorId,
                    InstructorName = c.Instructor != null ? c.Instructor.Name : string.Empty
                })
                .ToListAsync();

            return Ok(courses);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public async Task<IActionResult> Create(CourseDto dto)
        {
            var course = new Models.Course
            {
                Title = dto.Title,
                Description = dto.Description,
                Category = Enum.Parse<Models.Category>(dto.Category),
                InstructorId = dto.InstructorId
            };

            _context.Courses.Add(course);
            await _context.SaveChangesAsync();
            return Ok();
        }
    }
}
