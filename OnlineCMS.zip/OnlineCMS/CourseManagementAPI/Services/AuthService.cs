using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Identity;
using Microsoft.IdentityModel.Tokens;
using OnlineCMS.Models;
using OnlineCMS.DTOs;
using OnlineCMS.Data;

namespace OnlineCMS.Services
{
    public class AuthService : IAuthService
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly AppDBContext _context;
        private readonly string _secretKey;

        public AuthService(
            UserManager<ApplicationUser> userManager,
            RoleManager<IdentityRole> roleManager,
            AppDBContext context,
            string secretKey)
        {
            _userManager = userManager;
            _roleManager = roleManager;
            _context = context;
            _secretKey = secretKey;
        }

        public async Task<AuthResponse> RegisterStudentAsync(RegisterStudentDto dto)
        {
            var student = new Student
            {
                Name = dto.FullName,
                Email = dto.Email
            };
            _context.Students.Add(student);
            await _context.SaveChangesAsync();

            var user = new ApplicationUser
            {
                UserName = dto.Email,
                Email = dto.Email,
                FullName = dto.FullName,
                StudentId = student.Id,
                EmailConfirmed = true
            };

            var result = await _userManager.CreateAsync(user, dto.Password);
            if (!result.Succeeded)
                return new AuthResponse { Success = false, Errors = result.Errors.Select(e => e.Description).ToList() };

            await _userManager.AddToRoleAsync(user, "Student");
            var token = await GenerateJwtToken(user);
            return new AuthResponse { Success = true, Token = token };
        }

        public async Task<AuthResponse> RegisterAdminAsync(RegisterAdminDto dto)
        {
            var user = new ApplicationUser
            {
                UserName = dto.Email,
                Email = dto.Email,
                FullName = dto.FullName,
                EmailConfirmed = true
            };

            var result = await _userManager.CreateAsync(user, dto.Password);
            if (!result.Succeeded)
                return new AuthResponse { Success = false, Errors = result.Errors.Select(e => e.Description).ToList() };

            await _userManager.AddToRoleAsync(user, "Admin");
            var token = await GenerateJwtToken(user);
            return new AuthResponse { Success = true, Token = token };
        }

        public async Task<AuthResponse> LoginAsync(LoginDto dto)
        {
            var user = await _userManager.FindByEmailAsync(dto.Email);
            if (user == null || !await _userManager.CheckPasswordAsync(user, dto.Password))
                return new AuthResponse { Success = false, Errors = new List<string> { "Invalid email or password." } };

            var token = await GenerateJwtToken(user);
            return new AuthResponse { Success = true, Token = token };
        }

        private async Task<string> GenerateJwtToken(ApplicationUser user)
        {
            var authClaims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, user.UserName ?? string.Empty),
                new Claim(ClaimTypes.NameIdentifier, user.Id),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            var roles = await _userManager.GetRolesAsync(user);
            authClaims.AddRange(roles.Select(role => new Claim(ClaimTypes.Role, role)));

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_secretKey));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: "Dana",
                audience: "Dana",
                claims: authClaims,
                expires: DateTime.UtcNow.AddHours(3),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
