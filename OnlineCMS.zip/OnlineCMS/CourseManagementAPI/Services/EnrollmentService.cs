using Microsoft.EntityFrameworkCore;
using OnlineCMS.Data;
using OnlineCMS.DTOs;
using OnlineCMS.Models;

namespace OnlineCMS.Services
{
    public class EnrollmentService : IEnrollmentService
    {
        private readonly AppDBContext _context;

        public EnrollmentService(AppDBContext context)
        {
            _context = context;
        }

        public async Task<bool> EnrollStudentAsync(int studentId, int courseId)
        {
            var existing = await _context.Enrollments
                .AnyAsync(e => e.StudentId == studentId && e.CourseId == courseId);

            if (existing) return false;

            var student = await _context.Students.FindAsync(studentId);
            var course = await _context.Courses.FindAsync(courseId);

            if (student == null || course == null)
            {
                return false;
            }

            var enrollment = new Enrollment
            {
                StudentId = studentId,
                CourseId = courseId,
                EnrollmentDate = DateOnly.FromDateTime(DateTime.UtcNow),
                Student = student,
                Course = course
            };

            _context.Enrollments.Add(enrollment);
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<List<EnrollmentDto>> GetEnrollmentsByStudentAsync(int studentId)
        {
            return await _context.Enrollments
                .Where(e => e.StudentId == studentId)
                .Include(e => e.Course)
                .Include(e => e.Student)
                .Select(e => new EnrollmentDto
                {
                    StudentId = e.StudentId,
                    StudentName = e.Student.Name,
                    CourseId = e.CourseId,
                    CourseTitle = e.Course.Title,
                    EnrollmentDate = e.EnrollmentDate
                })
                .ToListAsync();
        }

        public async Task<List<EnrollmentDto>> GetAllEnrollmentsAsync()
        {
            return await _context.Enrollments
                .Include(e => e.Course)
                .Include(e => e.Student)
                .Select(e => new EnrollmentDto
                {
                    StudentId = e.StudentId,
                    StudentName = e.Student.Name,
                    CourseId = e.CourseId,
                    CourseTitle = e.Course.Title,
                    EnrollmentDate = e.EnrollmentDate
                })
                .ToListAsync();
        }
    }
}
