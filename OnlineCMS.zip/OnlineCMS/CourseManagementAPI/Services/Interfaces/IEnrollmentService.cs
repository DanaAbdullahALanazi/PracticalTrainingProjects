using OnlineCMS.DTOs;

namespace OnlineCMS.Services
{
    public interface IEnrollmentService
    {
        Task<bool> EnrollStudentAsync(int studentId, int courseId);
        Task<List<EnrollmentDto>> GetEnrollmentsByStudentAsync(int studentId);
        Task<List<EnrollmentDto>> GetAllEnrollmentsAsync();
    }
}
