using OnlineCMS.DTOs;

public interface IAuthService
{
    Task<AuthResponse> RegisterStudentAsync(RegisterStudentDto dto);
    Task<AuthResponse> RegisterAdminAsync(RegisterAdminDto dto);
    Task<AuthResponse> LoginAsync(LoginDto dto);
}
